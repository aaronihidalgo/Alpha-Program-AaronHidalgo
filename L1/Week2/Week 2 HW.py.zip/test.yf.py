

# Exercise 1: Calculate daily returns from stock prices

stock_prices = [100.5, 102.3, 99.8, 103.7, 101.2]
daily_returns = [
    (stock_prices[i] - stock_prices[i-1]) / stock_prices[i-1]
    for i in range(1, len(stock_prices))
]
print(daily_returns)

# Exercise 2: Check if stock prices are above a threshold

stock_prices = [100.5, 102.3, 99.8, 103.7, 101.2]
price_checks = [price > 101.50 for price in stock_prices[1:]]
print(price_checks)

# Exercise 3: Generate trading signals based on daily returns

stock_prices = [100.5, 102.3, 99.8, 103.7, 101.2]
signals = []
for i in range(1, len(stock_prices)):
    daily_return = (stock_prices[i] - stock_prices[i - 1]) / stock_prices[i - 1]
    if daily_return > 0.02:
        signals.append("Buy")
    elif daily_return < -0.02:
        signals.append("Sell")
        print(signals)
        break
    else:
        signals.append("Hold")
else:
    print(signals)

# Exercise 4: Trading strategy function

def trading_strategy(prices):
    last_price = prices[-1]
    prev_return = (prices[-1] - prices[-2]) / prices[-2]
    avg_3_day = sum(prices[-3:]) / 3
    recommendation = "Hold"

    if last_price > 101 and prev_return > 0:
        recommendation = "Buy"
    elif avg_3_day < 100:
        recommendation = "Sell"
    
    return {
        "Last Price": last_price,
        "Daily Return": prev_return,
        "3-Day Average": avg_3_day,
        "Recommendation": recommendation
    }

print(trading_strategy(stock_prices))

# Final Exercise: Momentum Strategy Class

class MomentumTrading:
    def __init__(self, prices):
        self.prices = prices
        self.cash = 10000.0
        self.shares = 0
        self.signals = []
        self.trades = []

    def execute(self):
        for i in range(1, len(self.prices)):
            return_today = (self.prices[i] - self.prices[i - 1]) / self.prices[i - 1]
            if return_today >= 0.02:
                self.signals.append("Buy")
            elif return_today <= -0.02:
                self.signals.append("Sell")
            else:
                self.signals.append("Hold")

        for i, action in enumerate(self.signals):
            price = self.prices[i + 1]
            if action == "Buy":
                if self.cash >= 10 * price:
                    self.cash -= 10 * price
                    self.shares += 10
                    self.trades.append((price, "Buy", 10))
            elif action == "Sell" and self.shares > 0:
                self.cash += self.shares * price
                self.trades.append((price, "Sell", self.shares))
                self.shares = 0

    def display_summary(self):
        print("Momentum Strategy Summary:")
        print(f"Signals: {', '.join(f'\'{s}\'' for s in self.signals)}")
        print(f"Trades: {self.trades}")
        print(f"Final Cash: ${self.cash:.1f}")
        print(f"Shares Owned: {self.shares}")
        total_value = self.cash + self.shares * self.prices[-1]
        print(f"Total Portfolio Value: ${total_value:.1f}")

if __name__ == "__main__":
    prices = [100.5, 102.3, 99.8, 103.7, 101.2]
    strategy = MomentumTrading(prices)
    strategy.execute()
    strategy.display_summary()